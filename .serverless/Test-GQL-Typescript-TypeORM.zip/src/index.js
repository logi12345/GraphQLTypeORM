(function(e, a) { for(var i in a) e[i] = a[i]; if(a.__esModule) Object.defineProperty(e, "__esModule", { value: true }); }(exports,
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 580:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const typeorm_1 = __webpack_require__(794);
const photo_1 = __webpack_require__(75);
const connection = typeorm_1.createConnection({
    type: "postgres",
    host: "localhost",
    port: 5432,
    username: "postgres",
    password: "password",
    database: "TSGQLTest",
    entities: [
        photo_1.Photo
    ],
    synchronize: true,
    logging: false
});
exports.default = connection;


/***/ }),

/***/ 607:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.graphqlHandler = void 0;
const apollo_server_lambda_1 = __webpack_require__(680);
const resolvers_1 = __webpack_require__(981);
const type_defs_1 = __webpack_require__(422);
__webpack_require__(906);
const database_1 = __importDefault(__webpack_require__(580));
const photo_1 = __webpack_require__(75);
database_1.default
    .then(connection => {
    let photo = new photo_1.Photo();
    photo.name = "Me and Bears";
    photo.description = "I am near polar bears";
    photo.filename = "photo-with-bears.jpg";
    photo.views = 1;
    photo.isPublished = true;
    return connection.manager
        .save(photo)
        .then(photo => {
        console.log("Photo has been saved. Photo id is", photo.id);
    });
}).catch(error => console.log(error));
const apolloServer = new apollo_server_lambda_1.ApolloServer({ resolvers: resolvers_1.resolvers, typeDefs: type_defs_1.typeDefs });
exports.graphqlHandler = apolloServer.createHandler();


/***/ }),

/***/ 75:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Photo = void 0;
const typeorm_1 = __webpack_require__(794);
let Photo = class Photo {
};
__decorate([
    typeorm_1.PrimaryGeneratedColumn(),
    __metadata("design:type", Number)
], Photo.prototype, "id", void 0);
__decorate([
    typeorm_1.Column({
        length: 100
    }),
    __metadata("design:type", String)
], Photo.prototype, "name", void 0);
__decorate([
    typeorm_1.Column("text"),
    __metadata("design:type", String)
], Photo.prototype, "description", void 0);
__decorate([
    typeorm_1.Column(),
    __metadata("design:type", String)
], Photo.prototype, "filename", void 0);
__decorate([
    typeorm_1.Column("decimal"),
    __metadata("design:type", Number)
], Photo.prototype, "views", void 0);
__decorate([
    typeorm_1.Column(),
    __metadata("design:type", Boolean)
], Photo.prototype, "isPublished", void 0);
Photo = __decorate([
    typeorm_1.Entity()
], Photo);
exports.Photo = Photo;


/***/ }),

/***/ 981:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.resolvers = void 0;
exports.resolvers = {
    Query: {
        testMessage: () => 'Hello World!',
    },
};


/***/ }),

/***/ 422:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.typeDefs = void 0;
const apollo_server_lambda_1 = __webpack_require__(680);
exports.typeDefs = apollo_server_lambda_1.gql `
  type Query {
    """
    A test message.
    """
    testMessage: String!
  }
`;


/***/ }),

/***/ 680:
/***/ ((module) => {

module.exports = require("apollo-server-lambda");;

/***/ }),

/***/ 906:
/***/ ((module) => {

module.exports = require("reflect-metadata");;

/***/ }),

/***/ 794:
/***/ ((module) => {

module.exports = require("typeorm");;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		if(__webpack_module_cache__[moduleId]) {
/******/ 			return __webpack_module_cache__[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	// module exports must be returned from runtime so entry inlining is disabled
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(607);
/******/ })()

));
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjL2luZGV4LmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYXBpLy4vc3JjL2RhdGFiYXNlL2luZGV4LnRzIiwid2VicGFjazovL2FwaS8uL3NyYy9pbmRleC50cyIsIndlYnBhY2s6Ly9hcGkvLi9zcmMvbW9kZWxzL3Bob3RvLnRzIiwid2VicGFjazovL2FwaS8uL3NyYy9yZXNvbHZlcnMudHMiLCJ3ZWJwYWNrOi8vYXBpLy4vc3JjL3R5cGUtZGVmcy50cyIsIndlYnBhY2s6Ly9hcGkvZXh0ZXJuYWwgXCJhcG9sbG8tc2VydmVyLWxhbWJkYVwiIiwid2VicGFjazovL2FwaS9leHRlcm5hbCBcInJlZmxlY3QtbWV0YWRhdGFcIiIsIndlYnBhY2s6Ly9hcGkvZXh0ZXJuYWwgXCJ0eXBlb3JtXCIiLCJ3ZWJwYWNrOi8vYXBpL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL2FwaS93ZWJwYWNrL3N0YXJ0dXAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtjcmVhdGVDb25uZWN0aW9ufSBmcm9tIFwidHlwZW9ybVwiO1xuaW1wb3J0IHtQaG90b30gZnJvbSBcIi4uL21vZGVscy9waG90b1wiO1xuXG5jb25zdCBjb25uZWN0aW9uID0gY3JlYXRlQ29ubmVjdGlvbih7XG4gICAgdHlwZTogXCJwb3N0Z3Jlc1wiLFxuICAgIGhvc3Q6IFwibG9jYWxob3N0XCIsXG4gICAgcG9ydDogNTQzMixcbiAgICB1c2VybmFtZTogXCJwb3N0Z3Jlc1wiLFxuICAgIHBhc3N3b3JkOiBcInBhc3N3b3JkXCIsXG4gICAgZGF0YWJhc2U6IFwiVFNHUUxUZXN0XCIsXG4gICAgZW50aXRpZXM6IFtcbiAgICAgICAgUGhvdG9cbiAgICBdLFxuICAgIHN5bmNocm9uaXplOiB0cnVlLFxuICAgIGxvZ2dpbmc6IGZhbHNlXG59KTtcblxuZXhwb3J0IGRlZmF1bHQgY29ubmVjdGlvbjsiLCJcbmltcG9ydCB7IEFwb2xsb1NlcnZlciB9IGZyb20gJ2Fwb2xsby1zZXJ2ZXItbGFtYmRhJztcbmltcG9ydCB7IHJlc29sdmVycyB9IGZyb20gJy4vcmVzb2x2ZXJzJztcbmltcG9ydCB7IHR5cGVEZWZzIH0gZnJvbSAnLi90eXBlLWRlZnMnO1xuaW1wb3J0IFwicmVmbGVjdC1tZXRhZGF0YVwiO1xuaW1wb3J0IERCY29uZWN0aW9uIGZyb20gJy4vZGF0YWJhc2UnXG4vLyBpbXBvcnQge2NyZWF0ZUNvbm5lY3Rpb259IGZyb20gXCJ0eXBlb3JtXCI7XG5pbXBvcnQge1Bob3RvfSBmcm9tIFwiLi9tb2RlbHMvcGhvdG9cIjtcblxuREJjb25lY3Rpb25cbi50aGVuKGNvbm5lY3Rpb24gPT4ge1xuXG4gICAgbGV0IHBob3RvID0gbmV3IFBob3RvKCk7XG4gICAgcGhvdG8ubmFtZSA9IFwiTWUgYW5kIEJlYXJzXCI7XG4gICAgcGhvdG8uZGVzY3JpcHRpb24gPSBcIkkgYW0gbmVhciBwb2xhciBiZWFyc1wiO1xuICAgIHBob3RvLmZpbGVuYW1lID0gXCJwaG90by13aXRoLWJlYXJzLmpwZ1wiO1xuICAgIHBob3RvLnZpZXdzID0gMTtcbiAgICBwaG90by5pc1B1Ymxpc2hlZCA9IHRydWU7XG5cbiAgICByZXR1cm4gY29ubmVjdGlvbi5tYW5hZ2VyXG4gICAgICAgICAgICAuc2F2ZShwaG90bylcbiAgICAgICAgICAgIC50aGVuKHBob3RvID0+IHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlBob3RvIGhhcyBiZWVuIHNhdmVkLiBQaG90byBpZCBpc1wiLCBwaG90by5pZCk7XG4gICAgICAgICAgICB9KTtcblxufSkuY2F0Y2goZXJyb3IgPT4gY29uc29sZS5sb2coZXJyb3IpKTtcblxuY29uc3QgYXBvbGxvU2VydmVyID0gbmV3IEFwb2xsb1NlcnZlcih7IHJlc29sdmVycywgdHlwZURlZnMgfSk7XG5cbmV4cG9ydCBjb25zdCBncmFwaHFsSGFuZGxlciA9IGFwb2xsb1NlcnZlci5jcmVhdGVIYW5kbGVyKCk7IiwiaW1wb3J0IHtFbnRpdHksIENvbHVtbiwgUHJpbWFyeUdlbmVyYXRlZENvbHVtbn0gZnJvbSBcInR5cGVvcm1cIjtcblxuQEVudGl0eSgpXG5leHBvcnQgY2xhc3MgUGhvdG8ge1xuXG4gICAgQFByaW1hcnlHZW5lcmF0ZWRDb2x1bW4oKVxuICAgIGlkITogbnVtYmVyO1xuXG4gICAgQENvbHVtbih7XG4gICAgICAgIGxlbmd0aDogMTAwXG4gICAgfSlcbiAgICBuYW1lITogc3RyaW5nO1xuXG4gICAgQENvbHVtbihcInRleHRcIilcbiAgICBkZXNjcmlwdGlvbiE6IHN0cmluZztcblxuICAgIEBDb2x1bW4oKVxuICAgIGZpbGVuYW1lITogc3RyaW5nO1xuXG4gICAgQENvbHVtbihcImRlY2ltYWxcIilcbiAgICB2aWV3cyE6IG51bWJlcjtcblxuICAgIEBDb2x1bW4oKVxuICAgIGlzUHVibGlzaGVkITogYm9vbGVhbjtcbn0iLCJcbmV4cG9ydCBjb25zdCByZXNvbHZlcnMgPSB7XG4gICAgUXVlcnk6IHtcbiAgICAgIHRlc3RNZXNzYWdlOiAoKSA9PiAnSGVsbG8gV29ybGQhJyxcbiAgICB9LFxuICAgIFxuICB9IiwiaW1wb3J0IHsgZ3FsIH0gZnJvbSAnYXBvbGxvLXNlcnZlci1sYW1iZGEnO1xuXG5leHBvcnQgY29uc3QgdHlwZURlZnMgPSBncWxgXG4gIHR5cGUgUXVlcnkge1xuICAgIFwiXCJcIlxuICAgIEEgdGVzdCBtZXNzYWdlLlxuICAgIFwiXCJcIlxuICAgIHRlc3RNZXNzYWdlOiBTdHJpbmchXG4gIH1cbmA7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiYXBvbGxvLXNlcnZlci1sYW1iZGFcIik7OyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlZmxlY3QtbWV0YWRhdGFcIik7OyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInR5cGVvcm1cIik7OyIsIi8vIFRoZSBtb2R1bGUgY2FjaGVcbnZhciBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX18gPSB7fTtcblxuLy8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbmZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG5cdGlmKF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0pIHtcblx0XHRyZXR1cm4gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdC8vIG5vIG1vZHVsZS5pZCBuZWVkZWRcblx0XHQvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuIiwiLy8gbW9kdWxlIGV4cG9ydHMgbXVzdCBiZSByZXR1cm5lZCBmcm9tIHJ1bnRpbWUgc28gZW50cnkgaW5saW5pbmcgaXMgZGlzYWJsZWRcbi8vIHN0YXJ0dXBcbi8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xucmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oNjA3KTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBOzs7Ozs7Ozs7OztBQ2xCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFFQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBRUE7QUFFQTtBQUNBO0FBQ0E7QTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMvQkE7QUFHQTtBQXFCQTtBQWxCQTtBQURBOztBQUNBO0FBS0E7QUFIQTtBQUNBO0FBQ0E7O0FBQ0E7QUFHQTtBQURBOztBQUNBO0FBR0E7QUFEQTs7QUFDQTtBQUdBO0FBREE7O0FBQ0E7QUFHQTtBQURBOztBQUNBO0FBcEJBO0FBREE7QUFDQTtBQUFBO0FBQ0E7QUFDQTtBOzs7Ozs7OztBQ0pBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0E7Ozs7Ozs7O0FDUkE7QUFFQTs7Ozs7OztBQU9BO0FBQ0E7QUFDQTtBOzs7OztBQ1hBO0FBQ0E7QTs7Ozs7QUNEQTtBQUNBO0E7Ozs7O0FDREE7QUFDQTtBOzs7O0FDREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN0QkE7QUFDQTtBQUNBO0FBQ0E7OztBIiwic291cmNlUm9vdCI6IiJ9